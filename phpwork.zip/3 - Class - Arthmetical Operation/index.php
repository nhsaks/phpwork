<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Arthmetical Operation</title>
  </head>
  <body>
    <?php

    echo "Arthmetical Operation <br>";
// Addition
    $v1 = 1;
    $v2 = 12;
    $add = $v1 + $v2;
echo $add."<br>";

// Substract

  $myvalue1 = 200;
  $myvalue2 = 500;

  $substract = $myvalue2 - $myvalue1;

  echo $substract."<br>";

// Multiplication

 $m = $v2 * $add;

 echo "$m.<br>";

// Division
 $d = $myvalue1 / $v2;

 echo "$d";





     ?>
  </body>
</html>
