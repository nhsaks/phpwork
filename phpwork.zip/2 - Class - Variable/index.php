<?php

// Varible are capable to store changaeable value.

$a = 2;

echo $a."<br>";

//  Changeable

$a = 10;

echo $a;

// Print Message

echo "<br>Program Ended";


 ?>
