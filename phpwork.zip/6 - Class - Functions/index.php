
<?php

// Builten Function

echo "<br> Date : ".date('d-m-y');
echo "<br> Date : ".date('D-M-Y');
echo "<br> Date : ".date('d-M-Y');


// User Defined Function

function mys($z){
  return $z * $z;
}

echo "<br> It is a User Defined Function ";

$a = 5;

echo "<br>".mys($a);





 ?>
