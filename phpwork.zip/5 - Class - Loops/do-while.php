<?php

$a = 1;

do {
  $a++;
  echo $a."<br>";
} while ($a <= 10);

// Calculation Then Repeation.
// Real Life Example TV start  Channel opened first. Then repeat to change





 ?>
