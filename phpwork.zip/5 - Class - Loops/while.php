<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>While Loop</title>
  </head>
  <body>

    <?php
// While Loop

$a = 1;

while ($a <= 10) {
  echo "$a";
$a++;
}


// Real Life Example
// Course start making but don't know complete time. When Course
// completed i stop to make.






     ?>

  </body>
</html>
