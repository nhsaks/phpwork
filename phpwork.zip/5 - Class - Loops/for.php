<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Loops</title>
  </head>
  <body>
    <?php

    echo "Loops<br>";

  // For Loop

  for ($i=0; $i <= 10; $i++) {

echo $i."<br>";

  }

  // Loop decreament --

echo "Decreamnet Loop here below <br>";

  for ($i=10; $i >= 0; $i--) {

echo $i."<br>";

  }


  // For Loop use for Search Operation - 
  //Real Life Example
  // I know how long i will do exersice.
  // Fix time is 20 minutes.





     ?>
  </body>
</html>
