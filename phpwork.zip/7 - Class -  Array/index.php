
<?php

$student[0] = "Riaz";
$student[1] = "Nawaz";
$student[2] = "Ajaz";

echo "<br> Student Name : ". $student[0];
echo "<br> Student Name : ". $student[1];
echo "<br> Student Name : ". $student[2];


 ?>
