<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Coditions</title>
  </head>
  <body>
    <?php

    echo "Conditions<br>";

    $a = 1;
    $b = 4;
// 1 Condtion Start

    if($a == $b)
    {
      echo "True";
    }
    else{
      echo "False <br>";
    }

    // 2 Condtion Start

        if($a != $b)
        {
          echo "True";
        }
        else{
          echo "False <br>";
        }


  // Only If Condtion

  if ($a == 1) {
    echo "<br> Condition is true message is printed";
  }

  if ($b == 10) {
    echo " <br> Condition is not true  that
    is why message is not printed";
  }


  // Other Class FB Real Time Condtion Example

  $email = "cp@gmail.com";
  $pass = "123";

  if ($pass == 123) {
  echo "<br>Password is True";
  }else{

    echo "Password is not true";

  }

  if ($email == $email) {
  echo "<br>Email is True";
  }else{

    echo "Email is not true";

  }





     ?>
  </body>
</html>
